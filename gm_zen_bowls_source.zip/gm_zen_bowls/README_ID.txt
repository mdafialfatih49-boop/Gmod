GM_ZEN_BOWLS — Garry’s Mod Map Source
====================================

Map name: gm_zen_bowls
Target: Garry’s Mod (Source Engine)
File: gm_zen_bowls.vmf

KONSEP YANG SUDAH DIBUAT
------------------------
- Plaza tertutup dengan skybox senja dan fog lembut.
- Kolam bundar 24 sisi, air dangkal (brush water), lantai batu, dan bibir kolam.
- Mangkuk besar di tengah serta beberapa mangkuk kecil dengan isi neon, kosong, dan mangkuk gelembung.
- Pilar batu klasik, dua bangku, gazebo kayu, planter, spawn point, dan nodegraph.
- Lampu hangat/cool accent serta ambient water/wind dari aset audio bawaan Half-Life 2.
- Tiga prop fisika berbentuk bola dari model PHX.

CATATAN PENTING
---------------
Ini adalah SOURCE VMF, belum berupa BSP yang siap dimainkan. VBSP/VVIS/VRAD tidak tersedia di lingkungan pembuat file ini, jadi proses compile belum dijalankan dan hasil BSP belum dapat dijamin.

Ada beberapa elemen yang sengaja dibuat sebagai brushwork agar tidak memerlukan model custom. Efek gelembung dibuat sebagai sprite kecil statis + suara tetesan; belum berupa simulasi partikel bergerak. Pantulan air/cubemap perlu diperbarui dari dalam game/kompiler agar sesuai pencahayaan.

CARA COMPILE DI HAMMER (PC)
---------------------------
1. Letakkan gm_zen_bowls.vmf di folder kerja Hammer.
2. Buka file dengan Hammer yang dikonfigurasi untuk Garry’s Mod.
3. Pastikan game directory mengarah ke folder garrysmod.
4. Gunakan tool compile GMod: VBSP, VVIS, dan VRAD.
5. Atur skybox/fog/cubemap bila ingin menyesuaikan nuansa senja.
6. Salin gm_zen_bowls.bsp ke garrysmod/garrysmod/maps/.
7. Jalankan di konsol GMod: map gm_zen_bowls

NAVMESH NPC
-----------
VMF menyertakan info_node untuk nodegraph NPC. Navmesh tidak disimpan sebagai bagian VMF; buat navmesh dari dalam GMod setelah map BSP berhasil dibuka, memakai perintah nav_generate, lalu simpan dengan nav_save. Periksa kembali area yang dapat dilalui NPC di sekitar bibir kolam dan gazebo.

TROUBLESHOOTING
---------------
- Jika tekstur tertentu tidak ditemukan, ganti material tersebut di Hammer dengan material bawaan GMod yang tersedia.
- Model bola memakai models/props_phx/misc/ball.mdl; jika model PHX tidak terpasang/termuat, hapus prop_physics tersebut atau ganti model melalui Hammer.
- Jika kompilasi mengeluhkan brush water, periksa brush kolam dan pastikan hanya permukaan atas yang memakai nature/water_movingplane.
- File ini belum dites di Hammer/Source compiler. Anggap sebagai source awal yang siap dibuka dan disempurnakan, bukan BSP final teruji.
